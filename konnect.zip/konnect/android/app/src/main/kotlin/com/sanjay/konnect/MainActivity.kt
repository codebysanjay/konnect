package com.sanjay.konnect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
